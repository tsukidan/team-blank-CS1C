var searchData=
[
  ['data_222',['data',['../class_inventory_model.html#a71814253bb1422684310c6a8dda78d47',1,'InventoryModel::data()'],['../class_members_model.html#af6576ff455422a410129459f694e4b71',1,'MembersModel::data()']]],
  ['deletebyid_223',['deleteById',['../class_item.html#a44b910a40cd0b7752c505e3dd6677b5f',1,'Item::deleteById()'],['../class_member.html#a2f6de909f58f855d55aa5b5f5a0f7a15',1,'Member::deleteById()']]]
];
