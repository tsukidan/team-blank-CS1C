var searchData=
[
  ['purchase_256',['Purchase',['../class_purchase.html#a38aa12e4db7068596ad04e359917c05b',1,'Purchase::Purchase()'],['../class_purchase.html#a58d9633645b757736b7d1a297ac8da40',1,'Purchase::Purchase(int memberId, int itemId, QDate date, int quantity)'],['../class_purchase.html#a64e4bdf63afac0a0abd4b3b478e28626',1,'Purchase::Purchase(QSqlQuery &amp;query)']]]
];
