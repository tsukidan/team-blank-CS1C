var searchData=
[
  ['purchase_158',['Purchase',['../struct_seed_data_1_1_purchase.html',1,'SeedData::Purchase'],['../class_purchase.html',1,'Purchase']]]
];
