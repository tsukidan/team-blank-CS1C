var searchData=
[
  ['price_309',['price',['../struct_seed_data_1_1_purchase.html#a755024e014ac14a2b60f29997421a800',1,'SeedData::Purchase']]]
];
