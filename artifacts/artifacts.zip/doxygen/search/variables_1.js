var searchData=
[
  ['itemname_305',['itemName',['../struct_seed_data_1_1_purchase.html#a5223f82142e44aa8419e9c405a1fb7c0',1,'SeedData::Purchase']]]
];
