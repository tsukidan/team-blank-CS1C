var searchData=
[
  ['quantity_310',['quantity',['../struct_seed_data_1_1_purchase.html#adfb6ccad9b987b6dfcb82e15afea204f',1,'SeedData::Purchase']]]
];
