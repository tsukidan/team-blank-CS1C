#ifndef UTILS_H
#define UTILS_H

#include <QString>

namespace Utils {
QString moneyDisplay(double cents);
}
#endif